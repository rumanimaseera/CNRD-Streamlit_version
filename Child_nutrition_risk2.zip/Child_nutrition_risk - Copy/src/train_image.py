import os
import pandas as pd
import numpy as np
from tqdm import tqdm
import joblib

from utils import load_mobilenet_embed_model, image_to_embedding
from PIL import Image

DATA_PATH = "src/data/dataset.csv"
OUTPUT_PATH = "src/data/dataset_with_embeddings.csv"
EMB_ARRAY_PATH = "src/data/image_embeddings.npy"

def main():
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Dataset not found at {DATA_PATH}")

    df = pd.read_csv(DATA_PATH)
    if "image_path" not in df.columns:
        raise ValueError("Dataset must have an 'image_path' column for image embedding processing.")

    embed_model = load_mobilenet_embed_model()
    embeddings = []

    for img_path in tqdm(df["image_path"], desc="Processing images"):
        if not os.path.exists(img_path):
            print(f"⚠️ Warning: Image {img_path} not found. Skipping.")
            embeddings.append(np.zeros((1280,)))
            continue
        try:
            img = Image.open(img_path).convert("RGB")
            emb = image_to_embedding(img, embed_model=embed_model)
        except Exception as e:
            print(f"Error processing {img_path}: {e}")
            emb = np.zeros((1280,))
        embeddings.append(emb)

    embeddings = np.array(embeddings)
    np.save(EMB_ARRAY_PATH, embeddings)

    # Add index reference to dataframe
    df["embedding_index"] = list(range(len(embeddings)))
    df.to_csv(OUTPUT_PATH, index=False)
    print(f"✅ Saved embeddings array to {EMB_ARRAY_PATH}")
    print(f"✅ Saved updated dataset to {OUTPUT_PATH}")

if __name__ == "__main__":
    main()
