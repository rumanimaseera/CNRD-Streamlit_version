import os
import pandas as pd
import numpy as np
import joblib

from sklearn.ensemble import RandomForestClassifier, StackingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier

from preprocess import fit_and_save_preprocessor, load_preprocessor

DATA_PATH = "src/data/dataset_with_embeddings.csv"   # after running train_image.py
EMB_ARRAY_PATH = "src/data/image_embeddings.npy"
MODEL_PATH = "models/ensemble_model.joblib"

def load_data():
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Dataset not found at {DATA_PATH}")

    df = pd.read_csv(DATA_PATH)
    X_tab = df.drop(columns=["RiskLabel"], errors="ignore")

    # Load embeddings
    if os.path.exists(EMB_ARRAY_PATH):
        embeddings = np.load(EMB_ARRAY_PATH)
        if "embedding_index" in df.columns:
            emb = np.array([embeddings[i] for i in df["embedding_index"]])
        else:
            emb = embeddings
        X_tab = X_tab.drop(columns=["image_path", "embedding_index"], errors="ignore")
    else:
        print("⚠️ No embeddings found. Proceeding without image features.")
        emb = None

    y = None
    if "RiskLabel" in df.columns:
        y = df["RiskLabel"]

    return X_tab, emb, y

def build_and_train(X_tab, emb, y):
    # Fit preprocessing
    preprocessor = fit_and_save_preprocessor(X_tab, save_path="models/preprocessor.joblib")

    X_proc = preprocessor.transform(X_tab)

    if emb is not None:
        X_combined = np.hstack([X_proc, emb])
    else:
        X_combined = X_proc

    # Define base learners
    rf = RandomForestClassifier(n_estimators=200, random_state=42)
    xgb = XGBClassifier(n_estimators=300, learning_rate=0.05, max_depth=5, random_state=42, use_label_encoder=False, eval_metric="mlogloss")
    lgbm = LGBMClassifier(n_estimators=300, learning_rate=0.05, max_depth=-1, random_state=42)

    # Ensemble model
    ensemble = StackingClassifier(
        estimators=[("rf", rf), ("xgb", xgb), ("lgbm", lgbm)],
        final_estimator=LogisticRegression(max_iter=1000),
        n_jobs=-1
    )

    if y is not None:
        ensemble.fit(X_combined, y)
        joblib.dump(ensemble, MODEL_PATH)
        print(f"✅ Model trained and saved to {MODEL_PATH}")
        y_pred = ensemble.predict(X_combined)
        print("Classification Report:\n", classification_report(y, y_pred))
    else:
        print("⚠️ No labels found in dataset. Skipping training.")

def main():
    X_tab, emb, y = load_data()
    build_and_train(X_tab, emb, y)

if __name__ == "__main__":
    main()
