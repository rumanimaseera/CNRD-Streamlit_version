import pandas as pd
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
import joblib

NUMERIC_DEFAULTS = ['Age', 'Weight', 'Height', 'BMI', 'Birth Weight (kg)', 
                    'Family Size', 'Meals per Day', 'Appetite Level']
CATEGORICAL_DEFAULTS = ['Gender', "Mother's Education", "Father's Education", 
                        'Region / Area', 'Vaccination Status', 
                        'Access to Clean Water', 'Place of Birth', 
                        'Sanitation Access', 'Food Habits', 'Inherited Diseases']

def compute_bmi_if_missing(df):
    if 'BMI' not in df.columns or df['BMI'].isnull().any():
        if 'Weight' in df.columns and 'Height' in df.columns:
            h_m = df['Height'] / 100.0
            df['BMI'] = df['Weight'] / (h_m ** 2)
    return df

def build_preprocessor(numeric_features=None, categorical_features=None):
    if numeric_features is None:
        numeric_features = NUMERIC_DEFAULTS
    if categorical_features is None:
        categorical_features = CATEGORICAL_DEFAULTS

    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])

    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
        ('onehot', OneHotEncoder(handle_unknown='ignore'))
    ])

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, numeric_features),
            ('cat', categorical_transformer, categorical_features)
        ], remainder='drop'
    )
    return preprocessor

def fit_and_save_preprocessor(df, save_path='models/preprocessor.joblib',
                              numeric_features=None, categorical_features=None):
    df = compute_bmi_if_missing(df)
    preprocessor = build_preprocessor(numeric_features, categorical_features)
    X = df[numeric_features + categorical_features]
    preprocessor.fit(X)
    joblib.dump({'preprocessor': preprocessor, 
                 'num_features': numeric_features, 
                 'cat_features': categorical_features}, save_path)
    return preprocessor

def load_preprocessor(path='models/preprocessor.joblib'):
    data = joblib.load(path)
    return data['preprocessor'], data['num_features'], data['cat_features']
