import numpy as np
from PIL import Image
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input
from tensorflow.keras.preprocessing import image as keras_image

IMAGE_SIZE = (224, 224)

def load_mobilenet_embed_model():
    """
    Load MobileNetV2 pretrained on ImageNet.
    Outputs 1280-d embeddings when include_top=False and pooling='avg'.
    """
    model = MobileNetV2(weights='imagenet', include_top=False, pooling='avg')
    return model

def image_to_embedding(img_pil, embed_model=None):
    """
    Convert a PIL image to a MobileNetV2 embedding.
    """
    if embed_model is None:
        embed_model = load_mobilenet_embed_model()
    img = img_pil.resize(IMAGE_SIZE)
    arr = keras_image.img_to_array(img)
    arr = np.expand_dims(arr, axis=0)
    arr = preprocess_input(arr)
    emb = embed_model.predict(arr)
    emb = emb.reshape(-1)
    return emb

def read_image_from_upload(uploaded_file):
    """
    Read an uploaded image file (Streamlit) and convert to PIL.Image.
    """
    img = Image.open(uploaded_file).convert('RGB')
    return img

def map_prob_to_label(prob_vec, classes=['low', 'moderate', 'high']):
    """
    Map probability vector to risk label.
    """
    idx = int(np.argmax(prob_vec))
    return classes[idx]
