# Child Nutrition Risk Detector

This project predicts the nutritional risk of children using **tabular data**, **blood parameters**, and optionally **child photos**. It uses **ensemble learning** (Random Forest, XGBoost, LightGBM) and **image embeddings** from MobileNetV2.

---

## Folder Structure

child_nutrition_risk/
├─ models/ # Trained models will be saved here
├─ src/
│ ├─ data/ # Dataset CSV and embeddings
│ ├─ app.py # Streamlit app
│ ├─ preprocess.py # Preprocessing pipeline
│ ├─ train_tabular.py # Train ensemble model
│ ├─ train_image.py # Generate image embeddings
│ └─ utils.py # Utility functions
├─ sample_data_generation.py # Generate synthetic dataset
├─ requirements.txt # Python dependencies
└─ README.md


---

## Setup Instructions

1. **Clone the repository** (or copy the files locally).
2. **Create a Python virtual environment** (recommended):

```bash
python -m venv venv
venv\Scripts\activate       # Windows
source venv/bin/activate    # Mac/Linux

