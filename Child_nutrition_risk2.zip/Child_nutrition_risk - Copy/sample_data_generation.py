import pandas as pd
import numpy as np
import os

N = 200  # number of sample rows
np.random.seed(42)

def random_category(options):
    return np.random.choice(options, size=N)

ages = np.random.randint(6, 60, size=N)            # months
weights = np.round(np.random.normal(12, 3, size=N), 1)  # kg
heights = np.round(np.random.normal(90, 7, size=N), 1)  # cm
labels = np.random.choice(["low", "moderate", "high"], size=N, p=[0.6, 0.25, 0.15])

df = pd.DataFrame({
    "Age": ages,
    "Weight": weights,
    "Height": heights,
    "BMI": weights / ((heights/100.0)**2),
    "Gender": random_category(["Male", "Female"]),
    "Mother's Education": random_category(["none", "primary", "secondary", "higher"]),
    "Father's Education": random_category(["none", "primary", "secondary", "higher"]),
    "Household Income (monthly)": np.random.randint(2000, 50000, size=N),
    "Meals per Day": np.random.randint(1, 4, size=N),
    "Vaccination Status": random_category(["complete", "partial", "none"]),
    "Access to Clean Water": random_category(["yes", "no"]),
    "Region / Area": random_category(["urban", "rural"]),
    "Birth Weight (kg)": np.round(np.random.normal(2.8, 0.6, size=N), 2),
    "Family Size": np.random.randint(2, 8, size=N),
    "Food Habits": random_category(["mixed", "vegetarian"]),
    "Inherited Diseases": random_category(["none", "some"]),
    "Appetite Level": np.random.randint(1, 6, size=N),
    "Place of Birth": random_category(["hospital", "home"]),
    "Sanitation Access": random_category(["yes", "no"]),
    "Breastfeeding Duration (months)": np.random.randint(0, 24, size=N),
    "Hemoglobin": np.round(np.random.normal(11.5, 1.2, size=N), 1),
    "Ferritin": np.round(np.random.normal(25, 10, size=N), 1),
    "CRP": np.round(np.random.exponential(1, size=N), 2),
    "RiskLabel": labels,
    # placeholder image paths (replace with real images if you have)
    "image_path": [f"src/data/sample_images/img_{i:03d}.jpg" for i in range(N)]
})

os.makedirs("src/data", exist_ok=True)
df.to_csv("src/data/dataset.csv", index=False)
print("✅ Sample dataset saved to src/data/dataset.csv")
